package main.chessMovement;

/**
 * Created by agustin on 3/4/17.
 */
public class AllPathsDisplayedException extends RuntimeException {

    public AllPathsDisplayedException(String m) {
        super(m);
    }

    public AllPathsDisplayedException() {
    }
}
