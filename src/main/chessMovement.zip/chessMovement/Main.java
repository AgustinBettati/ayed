package main.chessMovement;

/**
 * Created by agustin on 26/3/17.
 */
public class Main {
    public static void main(String[] args) {
        new ChessController();
    }
}
